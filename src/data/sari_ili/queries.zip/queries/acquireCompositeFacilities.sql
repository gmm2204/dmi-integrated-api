SELECT *
FROM DimFacility;