SELECT [VariableId],
    [Ordinal],
    [Variable],
    [VariableValue],
    [VariableParentId]
FROM [dbo].[CascadeHelper];